from django.apps import AppConfig


class PlanesConfig(AppConfig):
    name = 'planes'
