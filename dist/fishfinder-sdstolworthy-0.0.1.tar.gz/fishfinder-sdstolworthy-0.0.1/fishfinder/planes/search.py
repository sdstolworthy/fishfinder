from planes.models import Airplane
from planes.pipeline.pipeline import AirplaneSearchPipeline


def run():
    AirplaneSearchPipeline().run()
